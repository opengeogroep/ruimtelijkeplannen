<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="2.0">
<context>
    <name>BestemmingsPlanDialogBase</name>
    <message>
        <location filename="../ruimtelijke_plannen_dialog_base.ui" line="19"/>
        <source>Zoek Ruimtelijk Plan</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../ruimtelijke_plannen_dialog_base.ui" line="33"/>
        <source>Click to add plan to map</source>
        <translation>Klik om plan toe te voegen aan kaart</translation>
    </message>
</context>
<context>
    <name>RuimtelijkePlannen</name>
    <message>
        <location filename="../ruimtelijke_plannen.py" line="332"/>
        <source>&amp;Ruimtelijke Plannen</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../ruimtelijke_plannen.py" line="285"/>
        <source>Click map query RuimtelijkePlannen</source>
        <translation>Klik kaart om RuimtelijkePlannen te bevragen</translation>
    </message>
    <message>
        <location filename="../ruimtelijke_plannen.py" line="354"/>
        <source>Plan not found.</source>
        <translation>Plan niet gevonden.</translation>
    </message>
    <message>
        <location filename="../ruimtelijke_plannen.py" line="358"/>
        <source>Plan type not supported.</source>
        <translation>Plantype wordt niet ondersteund.</translation>
    </message>
    <message>
        <location filename="../ruimtelijke_plannen.py" line="402"/>
        <source>Invalid layer: </source>
        <translation>Ongeldige laag: </translation>
    </message>
    <message>
        <location filename="../ruimtelijke_plannen.py" line="448"/>
        <source>No Plans found.</source>
        <translation>Geen plannen gevonden.</translation>
    </message>
</context>
</TS>
