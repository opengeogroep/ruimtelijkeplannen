<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="2.0">
<context>
    <name>BestemmingsPlanDialogBase</name>
    <message>
        <location filename="../ruimtelijke_plannen_dialog_base.ui" line="19"/>
        <source>Zoek Ruimtelijk Plan</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../ruimtelijke_plannen_dialog_base.ui" line="33"/>
        <source>Click to add plan to map</source>
        <translation>Klik om plan toe te voegen aan kaart</translation>
    </message>
</context>
<context>
    <name>RuimtelijkePlannen</name>
    <message>
        <location filename="../ruimtelijke_plannen.py" line="405"/>
        <source>&amp;Ruimtelijke Plannen</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../ruimtelijke_plannen.py" line="330"/>
        <source>Click map query RuimtelijkePlannen</source>
        <translation>Klik kaart om RuimtelijkePlannen te bevragen</translation>
    </message>
    <message>
        <location filename="../ruimtelijke_plannen.py" line="469"/>
        <source>Plan not found.</source>
        <translation>Plan niet gevonden.</translation>
    </message>
    <message>
        <location filename="../ruimtelijke_plannen.py" line="473"/>
        <source>Plan type not supported.</source>
        <translation>Plantype wordt niet ondersteund.</translation>
    </message>
    <message>
        <location filename="../ruimtelijke_plannen.py" line="525"/>
        <source>Invalid layer: </source>
        <translation>Ongeldige laag: </translation>
    </message>
    <message>
        <location filename="../ruimtelijke_plannen.py" line="573"/>
        <source>No Plans found.</source>
        <translation>Geen plannen gevonden.</translation>
    </message>
    <message>
        <location filename="../ruimtelijke_plannen.py" line="313"/>
        <source>Help</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../ruimtelijke_plannen.py" line="446"/>
        <source>Selected style folder not found. See message log for details.</source>
        <translation>De map behorend bij de geselecteerde stijl is niet gevonden. Bekijk het berichten venster voor meer details.</translation>
    </message>
    <message>
        <location filename="../ruimtelijke_plannen.py" line="516"/>
        <source>Style not found. See message log for details.</source>
        <translation>Stijl is niet gevonden. Bekijk het berichten venster voor meer details.</translation>
    </message>
    <message>
        <location filename="../ruimtelijke_plannen.py" line="321"/>
        <source>Settings</source>
        <translation>Instellingen</translation>
    </message>
</context>
</TS>
